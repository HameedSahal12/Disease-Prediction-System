# -*- coding: utf-8 -*-
"""
Created on Sun Mar 24 14:17:24 2024

@author: shalu
"""


import numpy as np
import pickle
import streamlit as st


# loading the saved model
loaded_model = pickle.load(open('C:/Users/shalu/Desktop/final_y_p/heart disease trined model/trained_model.sav', 'rb'))


# creating a function for Prediction

def heart_disease_prediction(input_data):
    

    # change the input data to a numpy array
    input_data_as_numpy_array= np.asarray(input_data)

    # reshape the numpy array as we are predicting for only on instance
    input_data_reshaped = input_data_as_numpy_array.reshape(1,-1)

    prediction = loaded_model.predict(input_data_reshaped)
    print(prediction)

    if (prediction[0]== 0):
      return 'The Person does not have a Heart Disease'
    else:
      return 'The Person has Heart Disease'
  
    
  
def main():
    
    
    # giving a title
    st.title('Heart Disease Prediction')
    
    
    # getting the input data from the user
    age = st.text_input('Age')
    sex = st.text_input('Sex')
    cp = st.text_input('Chest Pain Type')
    trestbps = st.text_input('Resting Blood Pressure')
    chol = st.text_input('Serum Cholestoral in mg/dl')
    fbs = st.text_input('Fasting Blood Sugar > 120 mg/dl')
    restecg = st.text_input('Resting Electrocardiographic Result')
    thalach = st.text_input('Maximum Heart Rate Achieved')
    exang = st.text_input('Exercise Include Angina')
    oldpeak = st.text_input('ST Depression include by exercise')
    slope = st.text_input('Slope of the peak exercise ST segment')
    ca = st.text_input('Major vassels colored by flourosopy')
    thal = st.text_input('thal:0 = normal; 1 = fixed defect; 2 = reversable defect')
    
    
    
    
    # code for Prediction
    heart_diagnosis = ''
    
    # creating a button for Prediction
    
    if st.button('Heart Disease Test Result'):
        
        
        user_input = [age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal]
        user_input = [float(x) for x in user_input]
        
        heart_diagnosis = loaded_model.predict([user_input])
        
        if heart_diagnosis[0] == 1:
            heart_diagnosis = 'The person is having heart disease'
        else:
            heart_diagnosis = 'The person does not have any heart disease'

       
        
    st.success(heart_diagnosis)
    
    
    
    
    
if __name__ == '__main__':
    main()